//
//  ViewController.swift
//  photoEditorApp
//
//  Created by mina raouf on 5/3/19.
//  Copyright © 2019 mina raouf. All rights reserved.
//

import UIKit
import CoreImage

class ViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var imageView: UIImageView!
    
    struct filter {
        let filterName : String
        var filterEffectValue : Any?
        var filterEffectalueName : String?
    
    
        init(filterName : String, filterEffectValue : Any?, filterEffectalueName : String?) {
            self.filterName = filterName
            self.filterEffectValue = filterEffectValue
            self.filterEffectalueName = filterEffectalueName
        }
    }
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    private func applyFilterTo(image : UIImage, filterEffect : filter) -> UIImage? {
       
        guard let cgImage = image.cgImage,
              let openGLContext = EAGLContext(api: .openGLES3) else {
            return nil
        }
        
        let context = CIContext(eaglContext: openGLContext)
        let ciImage = CIImage(cgImage: cgImage)
        let filter  = CIFilter(name: filterEffect.filterName)
        filter?.setValue(ciImage, forKey: kCIInputImageKey)
        
        if let filterEffectValue = filterEffect.filterEffectValue,
            let filterEffectValueName = filterEffect.filterEffectalueName{
            filter?.setValue(filterEffectValue, forKey: filterEffectValueName)
        }
        
        var filteredImage:UIImage?
        if let output = filter?.value(forKey: kCIOutputImageKey) as? CIImage,
            let cgiImageResult = context.createCGImage(output, from: output.extent){
            filteredImage = UIImage(cgImage: cgiImageResult)
        }
        
        return filteredImage
    }
    
    
    @IBAction func speia(_ sender: UIButton) {
        guard let image = imageView.image else{
            return
        }
        imageView.image = applyFilterTo(image: image, filterEffect: filter(filterName: "CISepiaTone", filterEffectValue: 0.70, filterEffectalueName: kCIInputIntensityKey))
        
    }
    
    @IBAction func phototransfer(_ sender: UIButton) {
        guard let image = imageView.image else{
            return
        }
        imageView.image = applyFilterTo(image: image, filterEffect: filter(filterName: "CIPhotoEffectProcess", filterEffectValue: nil, filterEffectalueName: nil))
    }
    
    
    
    
    
    
    
    
    
    @IBAction func pickAnImage(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a Source", preferredStyle: .actionSheet)
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action:UIAlertAction) in
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion: nil)
            }))
        }else{
            print("Camera is not working")
        }
 
        
        
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action:UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        
        
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        imageView.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }


}

